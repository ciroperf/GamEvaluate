package gamevaluate.model;

import java.sql.SQLException;
import java.util.Collection;

import gamevaluate.bean.GeneralUser;

public class GeneralUserManager implements ProductModel<GeneralUser>{

	@Override
	public GeneralUser doRetrieveByKey(int code) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<GeneralUser> doRetrieveAll(String order) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void doSave(GeneralUser product) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doUpdate(GeneralUser product) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean doDelete(int code) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

}

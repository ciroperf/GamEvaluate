package gamevaluate.model;

import java.sql.SQLException;
import java.util.Collection;

import gamevaluate.bean.Piattaforma;

public class PiattaformaManager implements ProductModel<Piattaforma>{

	@Override
	public Piattaforma doRetrieveByKey(int code) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Piattaforma> doRetrieveAll(String order) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void doSave(Piattaforma product) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doUpdate(Piattaforma product) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean doDelete(int code) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

}

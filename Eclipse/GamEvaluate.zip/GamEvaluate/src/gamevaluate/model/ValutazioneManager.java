package gamevaluate.model;

import java.sql.SQLException;
import java.util.Collection;

import gamevaluate.bean.Valutazione;

public class ValutazioneManager implements ProductModel<Valutazione>{

	@Override
	public Valutazione doRetrieveByKey(int code) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Valutazione> doRetrieveAll(String order) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void doSave(Valutazione product) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doUpdate(Valutazione product) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean doDelete(int code) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

}

package gamevaluate.bean;

public class GeneralUser {

}

package gamevaluate.bean;

public class Gioco {

}

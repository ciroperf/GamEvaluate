package gamevaluate.bean;

public class Genere {

}
